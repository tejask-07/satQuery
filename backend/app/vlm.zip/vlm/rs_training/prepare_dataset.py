"""Prepare verified image/question/answer records for RS-VLM training."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from .dataset import split_records


def _record_from_sample(sample: dict, image_root: Path) -> dict | None:
    """Convert a BigEarthNet.txt row only when its image is present locally."""
    question = sample.get("input")
    answer = sample.get("output")
    patch_id = sample.get("patch_id")
    if not isinstance(question, str) or not question.strip():
        return None
    if not isinstance(answer, str) or not answer.strip() or not isinstance(patch_id, str):
        return None

    candidates = [
        image_root / patch_id,
        image_root / f"{patch_id}.jpg",
        image_root / f"{patch_id}.png",
        image_root / f"{patch_id}.jpeg",
        image_root / f"{patch_id}.tif",
        image_root / f"{patch_id}.tiff",
        image_root / patch_id / f"{patch_id}.jpg",
        image_root / patch_id / f"{patch_id}.png",
    ]
    image_path = next((path for path in candidates if path.is_file()), None)
    if image_path is None:
        return None

    return {
        "image": str(image_path),
        "question": question.strip(),
        "answer": answer.strip(),
        "source": "BigEarthNet.txt",
        "patch_id": patch_id,
        "category": sample.get("category"),
        "type": sample.get("type"),
    }


def prepare_bigearthnet(
    output: Path,
    image_root: Path,
    limit: int | None = None,
) -> dict[str, int]:
    """Stream BigEarthNet.txt and write only records with real local images."""
    from datasets import load_dataset

    dataset = load_dataset(
        "BIFOLD-BigEarthNetv2-0/BigEarthNet.txt",
        split="all_data",
        streaming=True,
    )
    records: list[dict[str, Any]] = []
    total = 0
    missing_images = 0
    invalid_records = 0
    for sample in dataset:
        total += 1
        record = _record_from_sample(sample, image_root)
        if record is None:
            if isinstance(sample.get("patch_id"), str):
                missing_images += 1
            else:
                invalid_records += 1
            continue
        records.append(record)
        if limit is not None and len(records) >= limit:
            break

    if not records:
        raise RuntimeError(
            "No usable RS-VLM training examples were found. "
            "Check --image-root and dataset availability."
        )

    train, validation, test = split_records(records, validation_fraction=0.1)
    split_records_by_name = (
        [(record, "train") for record in train]
        + [(record, "validation") for record in validation]
        + [(record, "test") for record in test]
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8") as handle:
        for record, split in split_records_by_name:
            record = {**record, "split": split}
            handle.write(json.dumps(record, ensure_ascii=True) + "\n")
    stats = {
        "total_records": total,
        "usable_records": len(records),
        "skipped_records": total - len(records),
        "missing_images": missing_images,
        "invalid_records": invalid_records,
        "train": len(train),
        "validation": len(validation),
        "test": len(test),
    }
    output.with_suffix(".stats.json").write_text(json.dumps(stats, indent=2), encoding="utf-8")
    return stats


def validate_manifest(path: Path) -> tuple[int, list[str]]:
    """Validate JSONL records without downloading models or datasets."""
    errors: list[str] = []
    count = 0
    with path.open(encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            try:
                record = json.loads(line)
            except json.JSONDecodeError as exc:
                errors.append(f"line {line_number}: invalid JSON ({exc.msg})")
                continue
            missing = [key for key in ("image", "question", "answer") if not record.get(key)]
            image = Path(record.get("image", ""))
            if missing:
                errors.append(f"line {line_number}: missing {', '.join(missing)}")
            elif not image.is_file():
                errors.append(f"line {line_number}: image not found: {image}")
            else:
                count += 1
    return count, errors


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--image-root", type=Path, required=True)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--validate", action="store_true")
    args = parser.parse_args()

    if args.validate:
        count, errors = validate_manifest(args.output)
        print(json.dumps({"valid_records": count, "errors": errors}, indent=2))
        raise SystemExit(1 if errors else 0)

    stats = prepare_bigearthnet(args.output, args.image_root, args.limit)
    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main()
